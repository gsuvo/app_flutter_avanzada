package com.example.app_flutter_avanzada

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
